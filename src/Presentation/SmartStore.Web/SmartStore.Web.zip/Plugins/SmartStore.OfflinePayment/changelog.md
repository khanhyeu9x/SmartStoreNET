﻿#Release Notes

##Offline Payment Methods 2.5.0
###New Features
* Option to exclude credit card types

##Offline Payment Methods 1.1
###Improvements
* Multistore configuration